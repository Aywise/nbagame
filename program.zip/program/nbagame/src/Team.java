import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

public class Team {
    List<Player> players;

    public Team(List<Player> players) {
        this.players = players;
    }

    public List<Player> chooseRandomPlayers() {
        List<Player> randomPlayers = new ArrayList<>(players);
        Collections.shuffle(randomPlayers);
        return randomPlayers.subList(0, Math.min(5, randomPlayers.size()));
    }

    public List<Player> chooseBestPlayers() {
        List<Player> bestPlayers = new ArrayList<>(players);
        bestPlayers.sort((p1, p2) -> Integer.compare(p2.Total(), p1.Total()));
        return bestPlayers.subList(0, Math.min(5, bestPlayers.size()));
    }

    public void addPlayer(Player player) {
        players.add(player);
    }

    public void removePlayer(Player player) {
        players.remove(player);
    }
}
