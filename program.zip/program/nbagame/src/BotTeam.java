import java.util.List;

class BotTeam extends Team {
    public BotTeam(List<Player> players) {
        super(players);
    }

    public Player chooseBestPlayer() {
        Player bestPlayer = players.get(0);
        int bestRating = bestPlayer.Total();

        for (Player player : players) {
            int playerRating = player.Total();
            if (playerRating > bestRating) {
                bestPlayer = player;
                bestRating = playerRating;
            }
        }

        return bestPlayer;
    }
}
