public class Player {
    String name;
    String surname;
    String position;
    String club;
    int offense;
    int defense;

    public Player(String name, String surname, String position, String club, int offense, int defense) {
        this.name = name;
        this.surname = surname;
        this.position = position;
        this.club = club;
        this.offense = offense;
        this.defense = defense;
    }

    public int Total() {
        return offense + defense;
    }

    @Override
    public String toString() {
        return name + " " + surname + " (" + club + ", " + position + ", Atak: " + offense + ", Obrona: " + defense + ")";
    }
}
