-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Czas generowania: 27 Sty 2025, 11:14
-- Wersja serwera: 10.4.27-MariaDB
-- Wersja PHP: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Baza danych: `nba`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `players`
--

CREATE TABLE `players` (
  `player_id` int(11) NOT NULL,
  `name` text DEFAULT NULL,
  `surname` text DEFAULT NULL,
  `position` text DEFAULT NULL,
  `team` text DEFAULT NULL,
  `offense` int(11) DEFAULT NULL,
  `defense` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `players`
--

INSERT INTO `players` (`player_id`, `name`, `surname`, `position`, `team`, `offense`, `defense`) VALUES
(1, 'Kevin', 'Durant', 'SF', 'Suns', 91, 81),
(2, 'Lebron', 'James', 'Small forward', 'LA Lakers', 90, 83),
(3, 'Stephen', 'Curry', 'Point guard', 'GSW', 90, 79),
(4, 'Kawhi', 'Leonard', 'Power forward', 'LA Clippers', 86, 85),
(5, 'Paul', 'George', 'Small forward', '76ers', 87, 82),
(6, 'Giannis', 'Antetokounmpo', 'Power forward', 'Bucks', 88, 91),
(7, 'Jayson', 'Tatum', 'Small forward', 'Celtics', 90, 84),
(8, 'Jaylen', 'Brown', 'Shooting guard', 'Celtics', 86, 82),
(9, 'Ja', 'Morant', 'Point guard', 'Grizzlies', 88, 78),
(10, 'Victor', 'Wembanyama', 'Center', 'Spurs', 80, 86),
(11, 'Shai', 'Gilgeous-Alexander', 'Point Guard', 'OKC', 90, 81),
(12, 'Joel', 'Embiid', 'Center', '76ers', 85, 89),
(13, 'Nikola', 'Jokic', 'Center', 'Nuggets', 90, 79),
(14, 'Anthony', 'Edwards', 'Shooting Guard', 'Timberwolves', 86, 82),
(15, 'Karl-Anthony', 'Towns', 'Power Forward', 'Knicks', 84, 78),
(16, 'Damian', 'Lillard', 'Point Guard', 'Bucks', 87, 76),
(17, 'Tyreese', 'Haliburton', 'Point Guard', 'Pacers', 87, 76),
(18, 'Luka', 'Doncic', 'Point Guard', 'Mavericks', 90, 79),
(19, 'Kyrie', 'Irving', 'Shooting Guard', 'Mavericks', 88, 73),
(20, 'Devin', 'Booker', 'Shooting Guard', 'Suns', 91, 76),
(21, 'Jrue', 'Holiday', 'Point Guard', 'Celtics', 83, 85),
(22, 'Zion', 'Williamson', 'Power forward', 'Pelicans', 87, 74),
(23, 'Demar', 'Derozan', 'Shooting guard', 'Bulls', 87, 77),
(24, 'Jeremy', 'Sochan', 'Power forward', 'Spurs', 73, 68),
(25, 'Derrick', 'Rose', 'Point guard', 'Grizzlies', 75, 71),
(26, 'Russell', 'Westbrook', 'Point guard', 'Nuggets', 84, 80),
(27, 'Anthony', 'Davis', 'Center', 'LA Lakers', 88, 88),
(28, 'Jimmy', 'Butler', 'Small forward', 'Heat', 86, 85),
(29, 'Bam', 'Adebayo', 'Center', 'Heat', 82, 84),
(30, 'Donovan', 'Mitchell', 'Shooting guard', 'Cavaliers', 87, 81),
(31, 'Darius', 'Garland', 'Point guard', 'Cavaliers', 84, 75),
(32, 'Jamal', 'Murray', 'Point guard', 'Nuggets', 85, 74),
(33, 'Michael', 'Porter Jr.', 'Small forward', 'Nuggets', 83, 71),
(34, 'Jalen', 'Brunson', 'Point guard', 'Knicks', 87, 75),
(35, 'RJ', 'Barrett', 'Small forward', 'Raptors', 83, 82),
(36, 'Kristaps', 'Porzingis', 'Center', 'Celtics', 80, 72),
(37, 'CJ', 'McCollum', 'Shooting guard', 'Pelicans', 80, 74),
(38, 'Brandon', 'Ingram', 'Small forward', 'Pelicans', 79, 70),
(39, 'De\'Aaron', 'Fox', 'Point guard', 'Kings', 83, 82),
(40, 'Domantas', 'Sabonis', 'Center', 'Kings', 84, 71),
(41, 'Alperen', 'Sengun', 'Center', 'Rockets', 80, 72),
(42, 'Jalen', 'Green', 'Shooting guard', 'Rockets', 82, 73),
(43, 'Cade', 'Cunningham', 'Point guard', 'Pistons', 85, 80),
(44, 'Zach', 'LaVine', 'Shooting guard', 'Bulls', 82, 76),
(45, 'Lonzo', 'Ball', 'Point guard', 'Bulls', 76, 77),
(46, 'Tyler', 'Herro', 'Shooting guard', 'Heat', 82, 70),
(47, 'Draymond', 'Green', 'Power forward', 'GSW', 76, 82),
(48, 'Andrew', 'Wiggins', 'Small forward', 'GSW', 77, 73),
(49, 'Klay', 'Thompson', 'Shooting guard', 'Mavericks', 80, 74),
(50, 'LaMelo', 'Ball', 'Point guard', 'Hornets', 85, 78),
(51, 'Brandon', 'Miller', 'Small forward', 'Hornets', 79, 70),
(52, 'Jaren', 'Jackson Jr.', 'Power forward', 'Grizzlies', 82, 83),
(53, 'Desmond', 'Bane', 'Shooting guard', 'Grizzlies', 81, 71),
(54, 'Trae', 'Young', 'Point guard', 'Hawks', 88, 71),
(55, 'Scottie', 'Barnes', 'Power Forward', 'Raptors', 80, 80),
(56, 'James', 'Harden', 'Shooting guard', 'Clippers', 83, 74);

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `players`
--
ALTER TABLE `players`
  ADD PRIMARY KEY (`player_id`);

--
-- AUTO_INCREMENT dla zrzuconych tabel
--

--
-- AUTO_INCREMENT dla tabeli `players`
--
ALTER TABLE `players`
  MODIFY `player_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
