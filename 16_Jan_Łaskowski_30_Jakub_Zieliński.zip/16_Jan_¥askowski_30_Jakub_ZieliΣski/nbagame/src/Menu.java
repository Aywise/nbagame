import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.sql.*;
class Menu {
    private static List<Player> players = new ArrayList<>();

    public static void menu() {
        loadPlayers();

        if (players.isEmpty()) {
            System.out.println("Brak zawodników.");
            return;
        }

        Game game = new Game(players);
        Scanner scanner = new Scanner(System.in);
        System.out.println("Wybierz drużynę 1 lub 2:");
        int userTeamChoice = scanner.nextInt();
        game.assignUserTeam(userTeamChoice);
        game.startGame();
    }

    private static void loadPlayers() {
        String url = "jdbc:mysql://localhost:3306/nba";
        String user = "root";
        String password = "";

        String query = "SELECT name, surname, position, team, offense, defense FROM players";

        try (Connection connection = DriverManager.getConnection(url, user, password);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            while (resultSet.next()) {
                String name = resultSet.getString("name");
                String surname = resultSet.getString("surname");
                String position = resultSet.getString("position");
                String team = resultSet.getString("team");
                int offense = resultSet.getInt("offense");
                int defense = resultSet.getInt("defense");

                players.add(new Player(name, surname, position, team, offense, defense));
            }
            System.out.println("Zawodnicy zostali wczytani z bazy danych.");
        } catch (SQLException e) {
            System.out.println("Błąd podczas wczytywania zawodników z bazy danych.");
            e.printStackTrace();
        }
    }
}