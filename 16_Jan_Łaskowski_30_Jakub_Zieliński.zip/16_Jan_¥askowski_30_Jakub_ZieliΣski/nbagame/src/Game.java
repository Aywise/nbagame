import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

public class Game {
    private List<Player> team1;
    private List<Player> team2;
    private List<Player> userTeam;

    /**
     * @param players Lista wszystkich zawodników
     */

    public Game(List<Player> players) {
        this.userTeam = new ArrayList<>();
        divideTeams(players);
    }

     /**
      * @param userChoice 1 dla druzyny 1, 2 dla druzyny 2
      */

    public void assignUserTeam(int userChoice) {
        if (userChoice == 1) {
            userTeam.addAll(chooseRandomPlayers(team1));
        } else if (userChoice == 2) {
            userTeam.addAll(chooseRandomPlayers(team2));
        } else {
            System.out.println("Niepoprawny wybór drużyny!");
        }
    }

    /**
     * Rozpoczyna gre
     */

    public void startGame() {
        if (userTeam.isEmpty()) {
            System.out.println("Najpierw wybierz drużynę.");
            return;
        }

        System.out.println("\nTwoja drużyna:");
        for (Player player : userTeam) {
            System.out.println(player);
        }

        System.out.println("\nRozpoczyna się gra!");
        playGame();
    }

    /**
     * Dzieli zawodnikow na dwie druzyny poprzez losowanie
     *
     * @param players Lista wszystkich zawodnikow
     */

    private void divideTeams(List<Player> players) {
        Collections.shuffle(players);
        int half = players.size() / 2;
        team1 = new ArrayList<>(players.subList(0, half));
        team2 = new ArrayList<>(players.subList(half, players.size()));
    }

    /**
     * Wybiera 5 losowych zawodnikow z druzyny
     *
     * @param team Druzyna, z ktorej wybierani sa zawodnicy
     * @return Lista 5 losowych zawodnikow
     */

    private List<Player> chooseRandomPlayers(List<Player> team) {
        List<Player> randomPlayers = new ArrayList<>(team);
        Collections.shuffle(randomPlayers);
        return randomPlayers.subList(0, Math.min(5, randomPlayers.size()));
    }
    /**
     * Uruchamia gre i wyswietla wyniki
     */
    private void playGame() {
        int userWins = 0;
        int botWins = 0;

        for (int i = 0; i < 5; i++) {
            Player userPlayer = userTeam.get(i);

            Player botPlayer = team2.get((int) (Math.random() * team2.size()));

            int userScore = userPlayer.Total();
            int botScore = botPlayer.Total();

            System.out.println("\nBitwa " + (i + 1) + ":");
            System.out.println("Ty: " + userPlayer + " - Suma Oceny: " + userScore);
            System.out.println("Bot: " + botPlayer + " - Suma Oceny: " + botScore);

            if (userScore > botScore) {
                System.out.println("Wygrałeś tę rundę!");
                userWins++;
            } else if (userScore < botScore) {
                System.out.println("Bot wygrał tę rundę!");
                botWins++;
            } else {
                System.out.println("Remis w tej rundzie!");
            }
        }

        System.out.println("\nWyniki:");
        System.out.println("Twoje Zwycięstwa: " + userWins);
        System.out.println("Zwycięstwa Bota: " + botWins);

        if (userWins > botWins) {
            System.out.println("Gratulacje! Wygrałeś grę!");
        } else if (userWins < botWins) {
            System.out.println("Bot wygrywa! Spróbuj ponownie.");
        } else {
            System.out.println("Remis! Obie drużyny są mocne.");
        }
    }
}
