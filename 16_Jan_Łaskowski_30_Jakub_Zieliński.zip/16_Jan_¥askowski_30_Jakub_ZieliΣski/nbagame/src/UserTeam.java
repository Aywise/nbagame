import java.util.List;

class UserTeam extends Team {
    public UserTeam(List<Player> players) {
        super(players);
    }

    public List<Player> chooseRandomPlayersForUser() {
        return chooseRandomPlayers();
    }
}


