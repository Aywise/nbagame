import java.util.List;

class UserTeam extends Team {
    public UserTeam(List<Player> players) {
        super(players);
    }
    /**
     * Wybiera 5 losowych zawodnikow dla druzyny uzytkownika
     *
     * @return Lista 5 losowych zawodnikow dla uzytkownika
     */

    public List<Player> chooseRandomPlayersForUser() {
        return chooseRandomPlayers();
    }
}


