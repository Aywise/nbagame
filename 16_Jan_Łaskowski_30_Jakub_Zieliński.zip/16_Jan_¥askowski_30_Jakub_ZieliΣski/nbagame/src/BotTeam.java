import java.util.List;

class BotTeam extends Team {
    public BotTeam(List<Player> players) {
        super(players);
    }

}