import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

public class Team {
    List<Player> players;

    /**
     * Konstruktor do tworzenia druzyny
     *
     * @param players Lista zawodnikow w druzynie
     */

    public Team(List<Player> players) {
        this.players = players;
    }

    public List<Player> chooseRandomPlayers() {
        List<Player> randomPlayers = new ArrayList<>(players);
        Collections.shuffle(randomPlayers);
        return randomPlayers.subList(0, Math.min(5, randomPlayers.size()));
    }

    /**
     * Dodaje zawodnika do druzyny
     *
     * @param player Zawodnik do dodania
     */

    public void addPlayer(Player player) {
        players.add(player);
    }

    /**
     * Usuwa zawodnika z druzyny
     *
     * @param player Zawodnik do usuniecia
     */

    public void removePlayer(Player player) {
        players.remove(player);
    }
}
