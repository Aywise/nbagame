import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Random;

public class UserGenerator {
    private static final String URL = "jdbc:mysql://localhost:3306/nba";
    private static final String USER = "root";
    private static final String PASSWORD = "";
    private static final String CHARACTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    public static void main(String[] args) {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement ps = conn.prepareStatement("INSERT INTO users (name) VALUES (?)")) {

            Random random = new Random();
            int count = 0;

            for (int i = 0; i < 1000000; i++) {
                ps.setString(1, generateRandomUsername(random, 12));
                ps.addBatch();

                if (++count % 1000 == 0) {
                    ps.executeBatch();
                    System.out.println("Wstawiono " + count + " użytkownikow");
                }
            }

            ps.executeBatch();
            System.out.println("Wszystkie rekordy zostaly pomyslnie dodane.");

        } catch (SQLException e) {
            System.err.println("Wystąpił problem z baza danych: " + e.getMessage());
        }
    }

    private static String generateRandomUsername(Random random, int length) {
        StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            sb.append(CHARACTERS.charAt(random.nextInt(CHARACTERS.length())));
        }
        return sb.toString();
    }
}