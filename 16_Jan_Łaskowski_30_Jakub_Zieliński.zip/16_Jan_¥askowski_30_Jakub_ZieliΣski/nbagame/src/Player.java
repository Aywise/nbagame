public class Player {
    String name;
    String surname;
    String position;
    String club;
    int offense;
    int defense;

    /**
     * Konstruktor do tworzenia nowego zawodnika.
     *
     * @param name    Imie zawodnika.
     * @param surname Nazwisko zawodnika.
     * @param position Pozycja zawodnika.
     * @param club Klub do ktorego nalezy zawodnik.
     * @param offense Umiejetnosc ofensywy.
     * @param defense Umiejetnosc defensywy.
     */

    public Player(String name, String surname, String position, String club, int offense, int defense) {

        this.name = name;
        this.surname = surname;
        this.position = position;
        this.club = club;
        this.offense = offense;
        this.defense = defense;
    }

    /**
     * @return Laczna wartosc umiejetnosci
     */
    public int Total() {
        return offense + defense;
    }



    @Override
    public String toString() {
        return name + " " + surname + " (" + club + ", " + position + ", Atak: " + offense + ", Obrona: " + defense + ")";
    }
}
